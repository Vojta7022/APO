#include <stdio.h>
#include <stdlib.h>

#define COLORS 3

int kernel[3][3] = {
    {0, -1, 0},
    {-1, 5, -1},
    {0, -1, 0}
};

int main(int argc, char const *argv[])
{
    FILE *fp = fopen(argv[1], "rb");

    int width, height, maxval;
    fscanf(fp, "P6\n%d\n%d\n%d\n", &width, &height, &maxval);

    unsigned char *image = malloc(width * height * COLORS);
    fread(image, 1, width * height * COLORS, fp);

    fclose(fp);

    unsigned char *output = malloc(width * height * COLORS);

    int histogram[] = {0, 0, 0, 0, 0};

    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            if (i == 0 || j == 0 || i == width - 1 || j == height - 1) {
                output[(j * width + i) * COLORS] = image[(j * width + i) * COLORS];
                output[(j * width + i) * COLORS + 1] = image[(j * width + i) * COLORS + 1];
                output[(j * width + i) * COLORS + 2] = image[(j * width + i) * COLORS + 2];
            } else {
                int sumR = 0, sumG = 0, sumB = 0;

                for (int k = -1; k <= 1; k++) {
                    for (int l = -1; l <= 1; l++) {
                        sumR += kernel[k + 1][l + 1] * image[((j + k) * width + (i + l)) * COLORS];
                        sumG += kernel[k + 1][l + 1] * image[((j + k) * width + (i + l)) * COLORS + 1];
                        sumB += kernel[k + 1][l + 1] * image[((j + k) * width + (i + l)) * COLORS + 2];
                    }
                }

                sumR = sumR < 0 ? 0 : (sumR > 255 ? 255 : sumR);
                sumG = sumG < 0 ? 0 : (sumG > 255 ? 255 : sumG);
                sumB = sumB < 0 ? 0 : (sumB > 255 ? 255 : sumB);

                output[(j * width + i) * COLORS] = sumR;
                output[(j * width + i) * COLORS + 1] = sumG;
                output[(j * width + i) * COLORS + 2] = sumB;

                histogram[(int)((0.2126 * sumR + 0.7152 * sumG + 0.0722 * sumB)/51)]++;
            }
        }
    }

    free(image);

    fp = fopen("output.ppm", "wb");
    fprintf(fp, "P6\n%d\n%d\n255\n", width, height);
    fwrite(output, 1, width * height * COLORS, fp);
    fclose(fp);

    free(output);

    fp = fopen("output.txt", "wb");
    fprintf(fp, "%d %d %d %d %d", histogram[0], histogram[1], histogram[2], histogram[3], histogram[4]);
    fclose(fp);

    return EXIT_SUCCESS;
}

